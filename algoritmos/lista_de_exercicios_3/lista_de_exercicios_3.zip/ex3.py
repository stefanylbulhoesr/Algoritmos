def soma (x,y,z):
    return x + y + z

print(soma(1,2,3))