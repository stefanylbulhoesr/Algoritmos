
def imprimir(n):
    for i in range(1,n+1):
        print(str(i) * i)
    return ...

n = int(input("Digite um valor: "))
imprimir(n)