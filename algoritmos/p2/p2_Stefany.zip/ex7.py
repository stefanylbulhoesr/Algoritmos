lista = ['Torvalds', 'Turing', 'Jobs', 'Gates', 'Babbage']
lista.sort()
print(f'Nomes em ordem alfabética: {lista}')