numeros = []
for i in range(1,5): #1 a 16
    n = int(input("Digite um número: "))
    numeros.append(n)
numeros.reverse()
print(numeros)
